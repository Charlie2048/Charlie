function [ fit_out ] = conventer(fit)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
% �ⲿ����Ҫ������ͷ��
fit=char(fit);
dj=find(fit=='��');
dj_num=length(dj);
%% �Ҽ�ͷ�ţ��̺����Ӵʣ�
for i=1:dj_num
    fit=char(fit);
    dj=find(fit=='��');
    fit_temp=char(fit);
    fit_mark=fit_temp;
    label=brackets(fit);
    pos_rj=dj(i);
    if(fit(pos_rj-1)==')')
        fit(pos_rj-1)='#';
        fit=string(fit);
        fit_mark(pos_rj-1)='#';
        pos_bra=find(label==label(pos_rj-1));
        temp(1)='~';
        for dj=1:(pos_bra(2)-pos_bra(1)+1)
            temp(dj+1)=fit_temp(pos_bra(1)+dj-1);
        end
        fit=fit.replace(fit_mark(:,[pos_bra(1):pos_bra(2)]),temp);
         temp='';
    else
        fit(pos_rj-1)='#';
        fit=string(fit);
        temp(1)='~';
        temp(2)=fit_temp(pos_rj-1);
        fit=fit.replace('#',temp);
        temp='';
    end
end
%% ���ͷ�ţ��̺����Ӵʣ�
fit=char(fit);
dj=find(fit=='��');
dj_num=length(dj);
for i=1:dj_num
    fit=char(fit);
    dj=find(fit=='��');
    fit_temp=char(fit);
    fit_mark=fit_temp;
    label=brackets(fit);
    pos_dj=dj(i);
    if(fit(pos_dj+1)=='(')
        fit(pos_dj+1)='#';
        fit=string(fit);
        fit_mark(pos_dj+1)='#';
        pos_bra=find(label==label(pos_dj+1));
        temp(1)='~';
        for dj=1:(pos_bra(2)-pos_bra(1)+1)
            temp(dj+1)=fit_temp(pos_bra(1)+dj-1);
        end
        fit=fit.replace(fit_mark(:,[pos_bra(1):pos_bra(2)]),temp);
         temp='';
    else
        fit(pos_dj+1)='#';
        fit=string(fit);
        temp(1)='~';
        temp(2)=fit_temp(pos_dj+1);
        fit=fit.replace('#',temp);
        temp='';
    end
end

%% �ϼ�ͷ����ǣ�
fit=char(fit);
dj=find(fit=='��');
dj_num=length(dj);

for i=1:dj_num
    fit=char(fit);
    dj=find(fit=='��');
    fit_temp=char(fit);
    fit_mark=fit_temp;
    label=brackets(fit);
    pos_dj=dj(i);
    
    if(fit(pos_dj+1)=='(')
        fit(pos_dj+1)='#';
        fit=string(fit);
        fit_mark(pos_dj+1)='#';
        pos_bra=find(label==label(pos_dj+1));
        temp(1)='~';
        for dj=1:(pos_bra(2)-pos_bra(1)+1)
            temp(dj+1)=fit_temp(pos_bra(1)+dj-1);
        end
        fit=fit.replace(fit_mark(:,[pos_bra(1):pos_bra(2)]),temp);
         temp='';
    else
        fit(pos_dj+1)='#';
        fit=string(fit);
        temp(1)='~';
        temp(2)=fit_temp(pos_dj+1);
        fit=fit.replace('#',temp);
        temp='';
    end
 fit=char(fit); 
 if(fit(pos_dj-1)==')')
        fit(pos_dj-1)='#';
        fit=string(fit);
        fit_mark(pos_dj-1)='#';
        pos_bra=find(label==label(pos_dj-1));
        temp(1)='~';
        for dj=1:(pos_bra(2)-pos_bra(1)+1)
            temp(dj+1)=fit_temp(pos_bra(1)+dj-1);
        end
        fit=fit.replace(fit_mark(:,[pos_bra(1):pos_bra(2)]),temp);
         temp='';
    else
        fit(pos_dj-1)='#';
        fit=string(fit);
        temp(1)='~';
        temp(2)=fit_temp(pos_dj-1);
        fit=fit.replace('#',temp);
        temp='';
    end
end

%% �¼�ͷ����ǣ�
fit=char(fit);
dj=find(fit=='��');
dj_num=length(dj);

for i=1:dj_num
    fit=char(fit);
    dj=find(fit=='��');
    fit_temp=char(fit);
    fit_mark=fit_temp;
    label=brackets(fit);
    pos_dj=dj(i);
    
    if(fit(pos_dj+1)=='(')
        fit(pos_dj+1)='#';
        fit=string(fit);
        fit_mark(pos_dj+1)='#';
        pos_bra=find(label==label(pos_dj+1));
        temp(1)='~';
        for dj=1:(pos_bra(2)-pos_bra(1)+1)
            temp(dj+1)=fit_temp(pos_bra(1)+dj-1);
        end
        fit=fit.replace(fit_mark(:,[pos_bra(1):pos_bra(2)]),temp);
         temp='';
    else
        fit(pos_dj+1)='#';
        fit=string(fit);
        temp(1)='~';
        temp(2)=fit_temp(pos_dj+1);
        fit=fit.replace('#',temp);
        temp='';
    end
 fit=char(fit);
 if(fit(pos_dj-1)==')')
        fit(pos_dj-1)='#';
        fit=string(fit);
        fit_mark(pos_dj-1)='#';
        pos_bra=find(label==label(pos_dj-1));
        temp(1)='~';
        for dj=1:(pos_bra(2)-pos_bra(1)+1)
            temp(dj+1)=fit_temp(pos_bra(1)+dj-1);
        end
        fit=fit.replace(fit_mark(:,[pos_bra(1):pos_bra(2)]),temp);
         temp='';
    else
        fit(pos_dj-1)='#';
        fit=string(fit);
        temp(1)='~';
        temp(2)=fit_temp(pos_dj-1);
        fit=fit.replace('#',temp);
        temp='';
    end
end

%% ��ʽ�滻
fit=string(fit);
fit=fit.replace('��','&');
fit=fit.replace('��','��');
fit=fit.replace('��','��');
fit=fit.replace('��','|');
fit=fit.replace('��','|');
fit=fit.replace('��','&');
fit=fit.replace(char(8596),'==');
fit=fit.replace(char(172),'~');
fit_out=char(fit);

end

