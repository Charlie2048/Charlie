function [label,min,max ] = match( fit , m )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
label=[];
nor=string(char(172));
x=string("��");
h=string("��");
lbra=string("(");
rbra=string(")");
for i=1:2^m
    quotient=i-1;
    for j=1:m
        assignment(m-j+1)=mod(quotient,2);
        quotient=(quotient-assignment(m-j+1))/2;
    end
    min(i)=lbra;
    max(i)=lbra;
    for j=1:m
        ele=string(char(64+j));
        if(assignment(j)==0)
            ele_min=nor+ele;
            ele_max=ele;
        else
            ele_max=nor+ele;
            ele_min=ele;            
        end
        if(j==1)
           min(i)=min(i)+ele_min;
           max(i)=max(i)+ele_max;
        else
        min(i)= min(i)+h+ele_min;
        max(i)=max(i)+x+ele_max;
        end
     end
    min(i)=min(i)+rbra;
    max(i)=max(i)+rbra;
    fit_temp=fit;
    for j=1:m
        fit_temp=replace(fit_temp,char(64+j),char(assignment(j)+48));
    end
    label(i)=eval(fit_temp);
end

end

